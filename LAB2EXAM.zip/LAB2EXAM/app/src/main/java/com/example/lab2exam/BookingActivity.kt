package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BookingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        // 1) Get extras from DetailsActivity
        val title = intent.getStringExtra("title") ?: "Apartment"
        val price = intent.getStringExtra("price") ?: ""
        val location = intent.getStringExtra("location") ?: ""

        // 2) Bind views
        val tvTitle = findViewById<TextView>(R.id.tvBookTitle)
        val tvLoc   = findViewById<TextView>(R.id.tvBookLocation)
        val tvPrice = findViewById<TextView>(R.id.tvBookPrice)
        val img     = findViewById<ImageView>(R.id.imgBookCover)

        // 3) Set UI
        tvTitle.text = "Booking – $title"
        tvLoc.text   = location
        tvPrice.text = price
        // img.setImageResource(cover) // if you also passed cover, you can set it here

        // 4) 🔽 YOUR SNIPPET GOES HERE (after binding + extras)
        findViewById<Button>(R.id.btnProceedPayment).setOnClickListener {
            startActivity(Intent(this, PaymentActivity::class.java).apply {
                putExtra("title", title)
                putExtra("price", price)
                putExtra("location", location)
            })
        }
    }
}
