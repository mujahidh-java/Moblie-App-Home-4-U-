package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
            val loggedIn = prefs.getBoolean("logged_in", false)
            val next = if (loggedIn) HomeActivity::class.java else LoginActivity::class.java

            startActivity(Intent(this, next).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            // finish() not needed after flags, but OK if present
        }, 1000)

    }
}
