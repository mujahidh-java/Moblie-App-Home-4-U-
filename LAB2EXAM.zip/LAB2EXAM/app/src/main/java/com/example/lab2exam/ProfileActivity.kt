package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)  // make sure this XML exists

        val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)

        // Show banner if we came from successful booking
        findViewById<TextView>(R.id.tvSuccess)?.apply {
            visibility = if (intent.getBooleanExtra("booking_success", false)) View.VISIBLE else View.GONE
        }

        // Populate fields (fallbacks used if nothing saved)
        findViewById<TextView>(R.id.tvName)?.text =
            prefs.getString("name", "Joh Doe")
        findViewById<TextView>(R.id.tvEmail)?.text =
            prefs.getString("email", "johdoe125@gmail.com")
        findViewById<TextView>(R.id.tvPhone)?.text =
            prefs.getString("phone", "+94 764353132")
        findViewById<TextView>(R.id.tvAddress)?.text =
            prefs.getString("address", "114, Main Street, Colombo - 02")

        // Logout
        findViewById<Button>(R.id.btnLogout)?.setOnClickListener {
            prefs.edit().putBoolean("logged_in", false).apply()
            startActivity(Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
        }
    }
}
