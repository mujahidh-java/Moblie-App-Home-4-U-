package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProcessingActivity : AppCompatActivity() {

    private val delayMs = 2000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_processing)

        val title = intent.getStringExtra("title") ?: "Apartment"
        val price = intent.getStringExtra("price") ?: ""

        // Update subtitle safely (the id now exists in the layout)
        findViewById<TextView>(R.id.tvProcessingSub).text = "$title • $price"

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, ProfileActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("booking_success", true)
                putExtra("title", title)
                putExtra("price", price)
            })
        }, delayMs)
    }
}
