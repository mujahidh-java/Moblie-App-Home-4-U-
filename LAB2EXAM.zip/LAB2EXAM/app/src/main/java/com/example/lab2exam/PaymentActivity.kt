package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PaymentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        val title = intent.getStringExtra("title") ?: "Apartment"
        val price = intent.getStringExtra("price") ?: ""

        findViewById<TextView>(R.id.tvPayTitle).text = "Payment"
        findViewById<TextView>(R.id.tvPaySub).text = "$title • $price"

        val etName   = findViewById<EditText>(R.id.etFullName)
        val etPhone  = findViewById<EditText>(R.id.etPhone)
        val etEmail  = findViewById<EditText>(R.id.etEmail)
        val etDate   = findViewById<EditText>(R.id.etCheckIn)
        val etNights = findViewById<EditText>(R.id.etNights)

        val rg       = findViewById<RadioGroup>(R.id.rgMethod)
        val cardSec  = findViewById<LinearLayout>(R.id.cardSection)

        val etCardName   = findViewById<EditText>(R.id.etCardName)
        val etCardNumber = findViewById<EditText>(R.id.etCardNumber)
        val etExpiry     = findViewById<EditText>(R.id.etExpiry)
        val etCvv        = findViewById<EditText>(R.id.etCvv)

        rg.setOnCheckedChangeListener { _, checkedId ->
            cardSec.visibility = if (checkedId == R.id.rbCard) android.view.View.VISIBLE else android.view.View.GONE
        }

        findViewById<Button>(R.id.btnPayNow).setOnClickListener {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val date = etDate.text.toString().trim()
            val nights = etNights.text.toString().trim()
            val methodId = rg.checkedRadioButtonId

            if (name.isEmpty() || phone.isEmpty() || email.isEmpty() || date.isEmpty() || nights.isEmpty() || methodId == -1) {
                Toast.makeText(this, "Please fill all fields and select a method.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (methodId == R.id.rbCard) {
                val cardName = etCardName.text.toString().trim()
                val cardNum  = etCardNumber.text.toString().trim()
                val expiry   = etExpiry.text.toString().trim()
                val cvv      = etCvv.text.toString().trim()

                if (cardName.isEmpty() || cardNum.length != 16 || !expiry.matches(Regex("""\d{2}/\d{2}""")) || cvv.length !in 3..4) {
                    Toast.makeText(this, "Enter valid card details.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }

            startActivity(Intent(this, ProcessingActivity::class.java).apply {
                putExtra("title", title)
                putExtra("price", price)
            })
        }

        findViewById<Button>(R.id.btnCancelPay).setOnClickListener { finish() }
    }
}
