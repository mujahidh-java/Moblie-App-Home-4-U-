package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val etName = findViewById<EditText>(R.id.etName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val etConfirm = findViewById<EditText>(R.id.etConfirm)
        val btnSignup = findViewById<Button>(R.id.btnSignup)
        val tvGoLogin = findViewById<TextView>(R.id.tvGoLogin)

        val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)

        btnSignup.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val pass  = etPassword.text.toString()
            val conf  = etConfirm.text.toString()

            when {
                name.isEmpty() || email.isEmpty() || pass.isEmpty() || conf.isEmpty() ->
                    Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()

                pass != conf ->
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()

                else -> {
                    // Demo-only storage
                    prefs.edit()
                        .putString("name", name)
                        .putString("email", email)
                        .putString("password", pass)
                        .putBoolean("logged_in", true)
                        .apply()

                    // Go to Home and CLEAR back stack so back won't return to signup/login
                    startActivity(Intent(this, HomeActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    })
                }
            }
        }

        tvGoLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    // Optional: if already logged in, skip signup screen
    override fun onStart() {
        super.onStart()
        val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        if (prefs.getBoolean("logged_in", false)) {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish()
        }
    }
}
