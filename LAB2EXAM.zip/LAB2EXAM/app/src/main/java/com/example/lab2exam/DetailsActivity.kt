package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        // Views
        val tvTitle = findViewById<TextView>(R.id.tvDetailsTitle)
        val tvLocation = findViewById<TextView>(R.id.tvDetailsLocation)
        val tvPrice = findViewById<TextView>(R.id.tvDetailsPrice)
        val imgCover = findViewById<ImageView>(R.id.imgCover)
        val img1 = findViewById<ImageView>(R.id.imgPhoto1)
        val img2 = findViewById<ImageView>(R.id.imgPhoto2)
        val img3 = findViewById<ImageView>(R.id.imgPhoto3)
        val img4 = findViewById<ImageView>(R.id.imgPhoto4)

        // Intent extras (with safe defaults)
        val title = intent.getStringExtra("title") ?: getString(R.string.details_title)
        val price = intent.getStringExtra("price") ?: getString(R.string.price_label)
        val location = intent.getStringExtra("location") ?: getString(R.string.location_label)

        val cover = intent.getIntExtra("cover", R.drawable.ap_cover)
        val p1 = intent.getIntExtra("p1", R.drawable.ap_living)
        val p2 = intent.getIntExtra("p2", R.drawable.ap_bathroom)
        val p3 = intent.getIntExtra("p3", R.drawable.ap_exterior)
        val p4 = intent.getIntExtra("p4", R.drawable.ap_exterior)

        // Apply to UI
        tvTitle.text = title
        tvPrice.text = price
        tvLocation.text = location
        imgCover.setImageResource(cover)
        img1.setImageResource(p1)
        img2.setImageResource(p2)
        img3.setImageResource(p3)
        img4.setImageResource(p4)

        // NEW: Book Now -> BookingActivity (pass summary)
        findViewById<Button>(R.id.btnBookNow)?.setOnClickListener {
            startActivity(Intent(this, BookingActivity::class.java).apply {
                putExtra("title", title)
                putExtra("price", price)
                putExtra("location", location)
                putExtra("cover", cover)
            })
        }

        // Back
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }
}
