package com.example.lab2exam

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    data class Property(
        val title: String,
        val price: String,
        val location: String,
        val cover: Int,
        val p1: Int,
        val p2: Int,
        val p3: Int,
        val p4: Int
    )

    private fun openDetails(property: Property) {
        val i = Intent(this, DetailsActivity::class.java).apply {
            putExtra("title", property.title)
            putExtra("price", property.price)
            putExtra("location", property.location)
            putExtra("cover", property.cover)
            putExtra("p1", property.p1)
            putExtra("p2", property.p2)
            putExtra("p3", property.p3)
            putExtra("p4", property.p4)
        }
        startActivity(i)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Card 1 (existing 2BR)
        val property1 = Property(
            "Sunny 2BR Apartment",
            "$1,200 / mo",
            "Dehiwala, Colombo",
            R.drawable.ap_cover,
            R.drawable.ap_living,
            R.drawable.ap_bathroom,
            R.drawable.ap_exterior,
            R.drawable.ap_exterior
        )

        findViewById<Button>(R.id.btnViewDetails).setOnClickListener {
            openDetails(property1)
        }

        // Card 2 (1BHK City View)
        val property2 = Property(
            "Cozy 1BHK · City View",
            "$950 / mo",
            "Wellawatte, Colombo",
            R.drawable.p2_cover,
            R.drawable.p2_bedroom,
            R.drawable.p2_bathroom,
            R.drawable.p2_exterior,
            R.drawable.p2_exterior
        )

        findViewById<Button>(R.id.btnViewDetails2).setOnClickListener {
            openDetails(property2)
        }

        // Card 3 (2BHK Near Beach)
        val property3 = Property(
            "2BHK · Near Beach",
            "$1,100 / mo",
            "Mount Lavinia",
            R.drawable.ap_exterior,
            R.drawable.ap_living,
            R.drawable.ap_bathroom,
            R.drawable.ap_cover,
            R.drawable.ap_exterior
        )

        findViewById<Button>(R.id.btnViewDetails3).setOnClickListener {
            openDetails(property3)
        }

        findViewById<android.widget.ImageButton>(R.id.btnProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }


    }
}
